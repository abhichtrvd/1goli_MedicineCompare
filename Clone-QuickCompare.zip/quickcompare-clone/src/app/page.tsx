"use client";
import React, { useState, useEffect, useRef, useCallback, Fragment } from "react";
import { supabase } from "@/lib/supabaseClient";
// ----------- MOCK AUTOSUGGEST AND SEARCH DATA -------------
const mockMedicines = [
  {
    id: 1,
    name: "Paracetamol 500mg Tablet",
    brand: "Crocin",
    manufacturer: "GSK Pharmaceuticals",
    salt: "Paracetamol 500mg",
    isGeneric: false,
    prescription: false,
    description: "Used for relief from fever and mild pain.",
    image: "https://images.unsplash.com/photo-1511174511562-5f97f2b2c02e?auto=format&fit=facearea&w=128&h=128",
    platforms: [
      {name:"1mg", logo:"https://assets.same-assets.com/1mg-logo.svg", price: 25, discounted: 23, discountPct: 8, deliveryEta: "4 hr", available: true, prescription: false, url: "#"},
      {name:"NetMeds", logo:"https://assets.same-assets.com/netmeds-logo.svg", price: 26, discounted: 21, discountPct: 19.2, deliveryEta: "Same day", available: true, prescription: false, url: "#"},
      {name:"PharmEasy", logo:"https://assets.same-assets.com/pharmeasy-logo.svg", price: 24, discounted: 22, discountPct: 8.3, deliveryEta: "2 hr", available: true, prescription: false, url: "#"},
      {name:"Apollo 24x7", logo:"https://assets.same-assets.com/apollo-logo.svg", price: 27, discounted: 24, discountPct: 11.1, deliveryEta: "3 hr", available: true, prescription: false, url: "#"},
    ]
  },
  {
    id: 2,
    name: "Amoxycillin 250mg Capsule",
    brand: "Mox",
    manufacturer: "Sun Pharma",
    salt: "Amoxycillin 250mg",
    isGeneric: true,
    prescription: true,
    description: "Antibiotic capsule for bacterial infections.",
    image: "https://images.unsplash.com/photo-1588776814546-a02c59fabee5?auto=format&fit=facearea&w=128&h=128",
    platforms: [
      {name:"PharmEasy", logo:"https://assets.same-assets.com/pharmeasy-logo.svg", price: 55, discounted: 49, discountPct: 10.9, deliveryEta: "5 hr", available: true, prescription: true, url: "#"},
      {name:"1mg", logo:"https://assets.same-assets.com/1mg-logo.svg", price: 53, discounted: 52, discountPct: 1.9, deliveryEta: "1 day", available: true, prescription: true, url: "#"},
      {name:"Apollo 24x7", logo:"https://assets.same-assets.com/apollo-logo.svg", price: 58, discounted: 57, discountPct: 1.7, deliveryEta: "2 day", available: false, prescription: true, url: "#"},
    ]
  }
];
const autosuggestList = ["Paracetamol 500mg Tablet", "Dolo 650 Tablet", "Amoxycillin 250mg Capsule", "Augmentin 375mg Tablet"];
// -----------------------------------------------------------

export default function HomePage() {
  const [search, setSearch] = useState("");
  const [autosuggest, setAutosuggest] = useState<string[]>([]);
  const [showAutosuggest, setShowAutosuggest] = useState(false);
  const [products, setProducts] = useState<typeof mockMedicines>(mockMedicines);
  const [wishlist, setWishlist] = useState<typeof mockMedicines>([]);
  const [showWishlist, setShowWishlist] = useState(false);
  const [compare, setCompare] = useState<typeof mockMedicines>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [details, setDetails] = useState<any|null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // ----------- FILTER STATE -----------
  const [filter, setFilter] = useState<{ isGeneric?: boolean|null, prescription?:boolean|null, manufacturer?:string|null }>({ isGeneric: null, prescription: null, manufacturer: null });
  const [sort, setSort] = useState<string>("");

  // ---- Autosuggest fetch from Supabase ----
  const handleInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearch(val);
    setShowAutosuggest(!!val);
    if (!val) return setAutosuggest([]);
    // Live DB
    const { data, error } = await supabase
      .from('medicines')
      .select('name')
      .ilike('name', `%${val}%`)
      .limit(8);
    if (!error && data && data.length > 0) {
      setAutosuggest(data.map((d:any)=>d.name));
    } else {
      setAutosuggest(autosuggestList.filter(s=>s.toLowerCase().includes(val.toLowerCase())));
    }
  };

  // ---- Search fetch from Supabase ----
  const handleSearch = async (name?:string) => {
    const q = name || search;
    setSearch(q);
    setShowAutosuggest(false);
    let query = supabase.from('medicines').select('*');
    if (q) query = query.ilike('name', `%${q}%`);
    if (filter.isGeneric !== null) query = query.eq('isGeneric', filter.isGeneric);
    if (filter.prescription !== null) query = query.eq('prescription', filter.prescription);
    if (filter.manufacturer) query = query.ilike('manufacturer', `%${filter.manufacturer}%`);
    const { data, error } = await query.limit(20);
    if (!error && data && data.length > 0) {
      setProducts(data.map((m,i)=>({ ...mockMedicines[0], ...m, id: m.id||i+1 })));
    } else {
      setProducts(mockMedicines.filter(m =>
        m.name.toLowerCase().includes(q.toLowerCase()) &&
        (filter.isGeneric===null || m.isGeneric===filter.isGeneric) &&
        (filter.prescription===null || m.prescription===filter.prescription) &&
        (filter.manufacturer? m.manufacturer.toLowerCase().includes(filter.manufacturer.toLowerCase()) : true)
      ));
    }
  };

  // Wishlist handlers
  const toggleWishlist = (p:any) => {
    if (wishlist.some(w => w.id===p.id)) setWishlist(wishlist.filter(w=>w.id!==p.id));
    else setWishlist([...wishlist,p]);
  };
  // Compare handlers
  const toggleCompare = (p:any) => {
    if (compare.some(c=>c.id===p.id)) setCompare(compare.filter(c=>c.id!==p.id));
    else if (compare.length<3) setCompare([...compare,p]);
  };
  const clearCompare = () => setCompare([]);

  return (
    <div className="max-w-2xl mx-auto min-h-screen">
      {/* ----------- HEADER ----------- */}
      <header className="sticky top-0 z-20 bg-white shadow flex flex-col items-center py-4">
        <div className="flex items-center space-x-4">
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAEr0lEQVR4nO2aS4iqQBCGb4ySw/YG7YAbYAfIDlWB3pzxGBdrdEw5m8pHaR80tHYGt94A8DHkTMlsP0gCOzw3wijcOZ3Lq2j0dQEl5gnkTZuJnRrideRlmE6pKrwO1gWNUA5AnUzofxw2AoOunIOMdwpBUkCOxi1AoQk5JFquOutS6KCCTCqAnReptkKgFLoFHwsRxSWS4pPLu/fVtXN3B+fjkFc5/0Vd/Tvfg6BOU1OxEWBb8akAdKo7xBdod68CC3U6JtBOkTpyCCQC/ECQyCqDjALfUt0DI0NaRgCrOBMVprGIevnZHJZdC4A9eZ4Swlyd06DCZQmb4AcJFmlkWEmZCzXUgQdnRGnVEiWcQZ7jZAIxiywI0fGFTkJKRZ3yjkYQHZFAJhUiNhQyMuUvGS3suMgKgo5QYQsKTk9W8VZp7wlA5YtKLFVx6WxpktlQs4BaSV9rZiFdxfkIMTePSS0tbQlHIpXqhUAb13iiAiXwEyH5FWaJg4omiQwgqmveoCnD9oQ6X1lxzchlR0gAiv9Vj3b4ie9UqBEsr8d/q6+sq5wAgvIguz5zqtCxe2A9wBc0tuDuTG4y8S/QdEKYjMvHy+BDYuKQwRaQFXDgSn3EESm8IisaTX+Ra0C97t9/MBbZ1KHUuAadMg87KzCj0OYMXpAEbOPrPk74tohMKQWELVtwOu4lSNR0bIGUIEXkAVWNoDZQk1AFUwjynayD6o+X0UB7u8Q0MRIBMJYq3K3mrJdV3r5BQl+F7W/rfeXk356ThFNaVKaKaMRZ7AyMkrvM42S6w2xo8/MX0BkqOYZDp96Rxz319eQWHLByQW5Q5iSAmkOGNxBNO43kVcrXEW/BwhBSwKRoZ3slsQf6M40Q7wTAfi7QBqOTKmV/4le5FsXn3skpO5iwNwqPr/6Eub7MA5FTO1u+w4ZxJJVWBDRJIIEgqQ4Z9w+TggC/N9K7EAAAAASUVORK5CYII="
            width={54}
            height={54}
            alt="1goli logo"
            className="rounded-full"
            style={{marginRight:20}}
          />
          <div>
            <span className="text-2xl font-bold text-pharmacy-green">1goli</span>
            <div className="text-pharmacy-blue font-medium text-lg">Medicine Compare</div>
          </div>
        </div>
      </header>

      {/* ----------- SEARCH ----------- */}
      <div className="flex flex-col items-center px-2 mb-4">
        <form className="w-full max-w-lg relative flex" onSubmit={e=>{e.preventDefault();handleSearch();}} autoComplete="off">
          <input
            className="w-full rounded-xl border border-pharmacy-green bg-pharmacy-light pl-4 pr-4 py-2 text-lg focus:outline-none"
            type="search"
            ref={inputRef}
            placeholder="Search medicines, compare prices, availability"
            value={search}
            onChange={handleInput}
            onFocus={()=>setShowAutosuggest(!!search)}
            onBlur={()=>setTimeout(()=>setShowAutosuggest(false),120)}
          />
          <button type="submit" className="ml-2 bg-pharmacy-green text-white rounded-xl px-5 py-2 font-bold hover:bg-pharmacy-blue transition">Search</button>
          {showAutosuggest && autosuggest.length > 0 && (
            <ul className="absolute z-10 top-12 left-0 right-0 bg-white border border-pharmacy-green rounded-xl text-black shadow">
              {autosuggest.map(s => (
                <li key={s}>
                  <button
                    type="button"
                    className="w-full text-left px-4 py-2 hover:bg-pharmacy-light"
                    style={{textAlign:'left'}}
                    onMouseDown={()=>handleSearch(s)}
                  >{s}</button>
                </li>
              ))}
            </ul>
          )}
        </form>
      </div>

      {/* ----------- PRODUCT LIST ----------- */}
      <div className="flex flex-col space-y-4 px-2">
        <div className="flex flex-wrap gap-2 items-center justify-between mb-4 mt-2 px-2">
          <div className="flex flex-wrap gap-2">
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.isGeneric === false ? "bg-pharmacy-light border-pharmacy-green text-pharmacy-green font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, isGeneric: false}));handleSearch();}}>Brand</button>
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.isGeneric === true ? "bg-pharmacy-light border-pharmacy-green text-pharmacy-green font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, isGeneric: true}));handleSearch();}}>Generic</button>
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.isGeneric === null ? "bg-pharmacy-light border-pharmacy-green text-pharmacy-green font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, isGeneric: null}));handleSearch();}}>All</button>
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.prescription === true ? "bg-blue-50 border-blue-600 text-blue-700 font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, prescription: true}));handleSearch();}}>Prescription Only</button>
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.prescription === false ? "bg-green-50 border-pharmacy-green text-pharmacy-green font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, prescription: false}));handleSearch();}}>OTC</button>
            <button className={`px-3 py-1 rounded-full border text-xs ${filter.prescription === null ? "bg-pharmacy-light border-pharmacy-green text-pharmacy-green font-semibold" : "border-gray-200 text-gray-700"}`} onClick={()=>{setFilter(f=>({...f, prescription: null}));handleSearch();}}>Any</button>
            <select className="ml-2 px-2 py-1 border rounded text-xs" value={filter.manufacturer || "All"} onChange={e=>{setFilter(f=>({...f, manufacturer:e.target.value==="All"?null:e.target.value}));handleSearch();}}>
              <option value="All">All Manufacturers</option>
              {manufacturers.map((m,i)=>(<option key={m+i} value={m}>{m}</option>))}
            </select>
            {(filter.isGeneric!==null || filter.prescription!==null || !!filter.manufacturer) && <button className="ml-2 text-xs text-pharmacy-blue underline" onClick={()=>{setFilter({isGeneric:null,prescription:null,manufacturer:null});handleSearch();}}>Clear</button>}
          </div>
          {/* Sorting dropdown (client-side sort for demo) */}
          <select className="px-2 py-1 border rounded text-xs" value={sort} onChange={e=>setSort(e.target.value)}>
            <option value="">Sort: Relevance</option>
            <option value="price-asc">Price Low-High</option>
            <option value="price-desc">Price High-Low</option>
            <option value="name">Name A-Z</option>
          </select>
        </div>
        {products.length === 0 ? (
          <div className="text-gray-500 text-center py-8">No medicines found for your search.</div>
        ) : products.map((product) => {
          const inWishlist = wishlist.some(w=>w.id===product.id);
          const inCompare = compare.some(c=>c.id===product.id);
          const bestPrice = Math.min(...product.platforms.map(p=>p.discounted));
          return (
            <div key={product.id} className="border bg-pharmacy-light rounded-xl shadow grid grid-cols-[auto_1fr_auto] items-start gap-3 p-4 relative">
              <img src={product.image} alt={product.name} className="w-16 h-16 rounded-lg object-cover border bg-white" />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-lg text-pharmacy-green cursor-pointer hover:underline" onClick={()=>setDetails(product)}>{product.name}</div>
                <div className="text-xs text-pharmacy-blue mt-1">{product.isGeneric ? <b>Generic</b> : <b>Brand: {product.brand}</b>} &bull; <span>Salt: <b>{product.salt}</b></span></div>
                <div className="text-xs text-gray-500">{product.manufacturer}</div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {product.platforms.map((pp, i) => (
                    <span key={i} className={"inline-flex items-center px-3 py-0.5 rounded border "+(pp.available ? ((pp.discounted===bestPrice?"border-brand-accent bg-brand-accent/70 text-black":"border-pharmacy-green bg-pharmacy-green/10 text-pharmacy-green")) : "border-gray-200 bg-gray-50 text-gray-400 line-through")}>
                      <img src={pp.logo} className="w-5 h-5 mr-1" />
                      ₹{pp.discounted}
                      {pp.discountPct > 0 && <span className="ml-2 text-gray-500 text-xs">-{pp.discountPct}%</span>} {pp.available ? '' : 'Out'}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-2 items-end">
                <button
                  onClick={()=>toggleWishlist(product)}
                  title={inWishlist?"Remove from wishlist":"Add to wishlist"}
                  className={`text-2xl ${inWishlist?'text-red-500':'text-gray-300 hover:text-red-500'} bg-white border-none px-1 py-0.5 rounded`}
                >♥</button>
                <button
                  onClick={()=>toggleCompare(product)}
                  className={`rounded px-2 py-1 text-xs ${inCompare?'bg-brand-accent text-black font-bold border border-brand-accent':'border border-pharmacy-green text-pharmacy-green hover:bg-pharmacy-green/10'}`}
                >{inCompare?"✓ Compare":"Compare"}</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ----------- STICKY COMPARE BAR ----------- */}
      {compare.length>0 && (
        <div className="fixed bottom-0 left-0 right-0 z-50 flex items-center bg-white border-t-2 border-pharmacy-green shadow-xl p-3 gap-3 justify-between max-w-2xl mx-auto rounded-t-xl animate-in fade-in slide-in-from-bottom duration-200">
          <div className="flex items-center gap-2 overflow-x-scroll no-scrollbar">
            {compare.map(prod=>(
              <div key={prod.id} className="flex flex-col items-center mx-2">
                <img src={prod.image} alt={prod.name} className="w-12 h-12 object-cover rounded border" />
                <span className="truncate w-16 text-xs mt-1 font-medium text-pharmacy-green">{prod.name.split(" ").slice(0,2).join(" ")}</span>
              </div>))}
          </div>
          <div className="flex items-center gap-2">
            <button className="bg-pharmacy-green text-white rounded-lg px-4 py-2 font-bold" onClick={()=>setShowCompare(true)} disabled={compare.length <2}>Compare Now</button>
            <button className="text-xs underline text-pharmacy-blue ml-1" onClick={clearCompare}>Clear</button>
          </div>
        </div>
      )}

      {/* ----------- WISHLIST FLOATING BUTTON ----------- */}
      <button
        className="fixed top-5 right-5 z-50 bg-pharmacy-green text-white font-bold rounded-full p-3 shadow hover:bg-pharmacy-blue transition"
        onClick={() => setShowWishlist(true)}
        aria-label="Show wishlist"
      >
        ♥ {wishlist.length}
      </button>
      {showWishlist && (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-end">
          <div className="bg-white shadow-2xl rounded-l-2xl w-[310px] p-4 h-full overflow-y-auto animate-in fade-in-from-right relative flex flex-col">
            <button className="absolute top-2 right-4 text-pharmacy-blue text-2xl" onClick={()=>setShowWishlist(false)}>&times;</button>
            <div className="text-lg mb-4 font-bold text-pharmacy-green">Wishlist</div>
            {wishlist.length===0 ? (
              <div className="text-gray-500 text-sm">No medicines wishlisted yet.</div>) :
              wishlist.map(p=>(<div key={p.id} className="flex items-center gap-2 mb-3 border-b pb-2"><img src={p.image} className="w-10 h-10 rounded border"/><div className="flex-1 min-w-0"><div className="truncate font-medium text-pharmacy-green">{p.name}</div><div className="text-xs text-gray-400 truncate">{p.brand} | {p.salt}</div></div><button onClick={()=>toggleWishlist(p)} className="ml-1 text-red-500 text-xl">&times;</button></div>))
            }
          </div>
        </div>
      )}

      {/* ----------- DETAILS MODAL ----------- */}
      {details && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl p-8 relative">
            <button onClick={()=>setDetails(null)} className="absolute top-2 right-3 text-xl text-pharmacy-blue">&times;</button>
            <div className="flex gap-4 items-center mb-4">
              <img src={details.image} alt={details.name} className="w-16 h-16 rounded-xl border shadow" />
              <div className="flex-1 min-w-0">
                <div className="font-bold text-lg text-pharmacy-green">{details.name}</div>
                <div className="text-xs text-gray-600 truncate">Brand: {details.brand} | Manufacturer: {details.manufacturer}</div>
                <div className="text-xs text-gray-600">Salt: {details.salt}</div>
                {details.prescription && <div className="text-blue-700 text-xs font-semibold">Prescription Required</div>}
              </div>
            </div>
            <div className="divide-y divide-gray-300">
              <div className="py-2 text-sm"><span className="font-medium">Description:</span><br/>{details.description}</div>
              {/* Additional details? */}
            </div>
          </div>
        </div>
      )}

      {/* ----------- COMPARE MODAL ----------- */}
      {showCompare && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center"><div className="bg-white shadow-2xl rounded-2xl max-w-5xl w-full mx-3 p-6 relative overflow-x-auto animate-in fade-in slide-in-from-bottom"><button onClick={()=>setShowCompare(false)} className="absolute top-2 right-4 text-pharmacy-blue text-2xl">&times;</button><div className="flex gap-6 items-end justify-center">{compare.map((prod,idx)=>(<div key={prod.id} className="flex-1 min-w-[250px] max-w-xs border rounded-xl shadow-md bg-pharmacy-light/60 p-4"><div className="flex items-center gap-3 mb-2"><img src={prod.image} alt={prod.name} className="w-16 h-16 rounded border" /><div className="flex-1"><div className="font-bold text-pharmacy-green text-md">{prod.name}</div><div className="text-xs text-gray-500">{prod.brand} | {prod.salt}</div><div className="text-xs text-gray-500">{prod.manufacturer}</div><span className={`text-xs px-2 py-px rounded ${prod.prescription ? "bg-blue-100 border border-blue-400 text-blue-700" : "bg-green-100 border-green-400 text-green-700"}`}>{prod.prescription ? "Rx" : "OTC"}</span></div></div><hr className="mb-2" />{prod.platforms.map(pp=>(<div key={pp.name} className="flex items-center justify-between mb-1 text-xs"><span className="flex items-center gap-1"><img src={pp.logo} alt={pp.name} className="w-5 h-5 rounded" />{pp.name}</span><span className={pp.available ? "text-pharmacy-green font-bold" : "text-gray-400 line-through"}>₹{pp.discounted}</span><span>{pp.available && pp.discountPct > 0 && <span className="text-xs bg-brand-accent/30 text-pharmacy-green px-1 rounded">-{pp.discountPct}%</span>}</span><span>{pp.available ? pp.deliveryEta : <span className="text-gray-400">—</span>}</span><span>{pp.prescription ? "Rx" : "OTC"}</span><a href={pp.url} className="text-pharmacy-blue underline font-medium ml-2" target="_blank" rel="noopener">Buy</a></div>))}</div>))}</div></div></div>)}

    </div>
  );
}
