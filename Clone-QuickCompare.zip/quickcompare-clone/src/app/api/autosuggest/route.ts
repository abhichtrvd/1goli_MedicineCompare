import { NextRequest, NextResponse } from "next/server";

const MEDICINE_NAMES = [
  "Crocin 500", "Paracetamol 500mg Tablet", "Dolo 650", "Amoxycillin 250mg Capsule", "Augmentin 375mg", "Penamox 250mg", "Aspirin", "Metformin 500mg", "Cetirizine", "Ibuprofen", "Calpol 500"
];

export async function POST(req: NextRequest) {
  const { query } = await req.json();
  const str = (query || "").toLowerCase();
  const results = MEDICINE_NAMES.filter(name => name.toLowerCase().includes(str)).slice(0, 6);
  return NextResponse.json({ suggestions: results });
}
