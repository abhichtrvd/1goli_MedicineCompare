// Provider registry for Indian online pharmacies, ready for real API/scraper wiring
export type ProviderID = "1mg" | "netmeds" | "pharmeasy" | "apollo" | "amazon" | "flipkart";
export interface Provider {
  id: ProviderID;
  name: string;
  logo: string;
  affiliateUrl: string | ((medicine: string) => string);
  fetchPrices: (medicine: string) => Promise<ProviderPriceEntry | null>;
}
export interface ProviderPriceEntry {
  name: string; // platform name
  logo: string;
  price: number;
  discounted: number;
  discountPct: number;
  deliveryEta: string;
  available: boolean;
  prescription: boolean;
  url: string;
}

// --- Provider List & Stubs --- //
export const PROVIDERS: Provider[] = [
  {
    id: "1mg",
    name: "1mg",
    logo: "https://assets.same-assets.com/1mg-logo.svg",
    affiliateUrl: (med) => `https://1mg.com/search/all?name=${encodeURIComponent(med)}`,
    async fetchPrices(medicine) {
      // TODO: Wire up real API or scraper here
      return {
        name: "1mg",
        logo: this.logo,
        price: 25,
        discounted: 23,
        discountPct: 8,
        deliveryEta: "4 hr",
        available: true,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  },
  {
    id: "netmeds",
    name: "NetMeds",
    logo: "https://assets.same-assets.com/netmeds-logo.svg",
    affiliateUrl: (med) => `https://www.netmeds.com/catalogsearch/result?q=${encodeURIComponent(med)}`,
    async fetchPrices(medicine) {
      return {
        name: "NetMeds",
        logo: this.logo,
        price: 26,
        discounted: 21,
        discountPct: 19.2,
        deliveryEta: "Same day",
        available: true,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  },
  {
    id: "pharmeasy",
    name: "PharmEasy",
    logo: "https://assets.same-assets.com/pharmeasy-logo.svg",
    affiliateUrl: (med) => `https://pharmeasy.in/search/all?name=${encodeURIComponent(med)}`,
    async fetchPrices(medicine) {
      return {
        name: "PharmEasy",
        logo: this.logo,
        price: 24,
        discounted: 22,
        discountPct: 8.3,
        deliveryEta: "2 hr",
        available: true,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  },
  {
    id: "apollo",
    name: "Apollo 24x7",
    logo: "https://assets.same-assets.com/apollo-logo.svg",
    affiliateUrl: (med) => `https://www.apollopharmacy.in/search-medicines/${encodeURIComponent(med)}`,
    async fetchPrices(medicine) {
      return {
        name: "Apollo 24x7",
        logo: this.logo,
        price: 27,
        discounted: 24,
        discountPct: 11.1,
        deliveryEta: "3 hr",
        available: true,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  },
  {
    id: "amazon",
    name: "Amazon Pharmacy",
    logo: "https://assets.same-assets.com/amazon-pharmacy-logo.svg",
    affiliateUrl: (med) => `https://www.amazon.in/s?k=${encodeURIComponent(med)}+pharmacy`,
    async fetchPrices(medicine) {
      return {
        name: "Amazon Pharmacy",
        logo: this.logo,
        price: 29,
        discounted: 29,
        discountPct: 0,
        deliveryEta: "Next day",
        available: true,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  },
  {
    id: "flipkart",
    name: "Flipkart Health+",
    logo: "https://assets.same-assets.com/flipkart-logo.svg",
    affiliateUrl: (med) => `https://www.flipkart.com/search?q=${encodeURIComponent(med)}+medicine`,
    async fetchPrices(medicine) {
      return {
        name: "Flipkart Health+",
        logo: this.logo,
        price: 30,
        discounted: 28,
        discountPct: 6.7,
        deliveryEta: "1 day",
        available: false,
        prescription: false,
        url: typeof this.affiliateUrl === "string" ? this.affiliateUrl : this.affiliateUrl(medicine)
      };
    }
  }
];

// --- How to Add a Provider ---
// 1. Add entry above, with id, name, logo, affiliateUrl pattern, and fetchPrices async function
// 2. Make fetchPrices call a real API, affiliate feed, or run a legal web scraping worker (see docs/legal)
