import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    locations: [
      { id: 1, name: "Mumbai" },
      { id: 2, name: "Bengaluru" },
      { id: 3, name: "Delhi" },
      { id: 4, name: "Hyderabad" },
      { id: 5, name: "Chennai" }
    ]
  });
}
