import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseClient";
import { PROVIDERS } from "../_providers";

// For fallback/demo only
const MEDICINE_META = {
  "Paracetamol 500mg Tablet": {
    id: 1,
    name: "Paracetamol 500mg Tablet",
    image: "https://images.unsplash.com/photo-1511174511562-5f97f2b2c02e?auto=format&fit=facearea&w=128&h=128",
    brand: "Crocin",
    manufacturer: "GSK Pharmaceuticals",
    salt: "Paracetamol 500mg",
    isGeneric: false,
    prescription: false,
    description: "Used for relief from fever and mild pain.",
    sideEffects: "Nausea, rash, liver problems (rare)",
    directions: "Take after food. Do not exceed 4g/day.",
    alternatives: "Dolo 650, Calpol 500"
  },
  "Amoxycillin 250mg Capsule": {
    id: 2,
    name: "Amoxycillin 250mg Capsule",
    image: "https://images.unsplash.com/photo-1588776814546-a02c59fabee5?auto=format&fit=facearea&w=128&h=128",
    brand: "Mox",
    manufacturer: "Sun Pharma",
    salt: "Amoxycillin 250mg",
    isGeneric: true,
    prescription: true,
    description: "Antibiotic capsule for bacterial infections.",
    sideEffects: "Diarrhea, allergy, stomach upset",
    directions: "Take as prescribed. Complete full course.",
    alternatives: "Augmentin 375mg, Penamox 250mg"
  }
};

export async function POST(req: NextRequest) {
  const { query } = await req.json();
  let medicinesFromDb = [];
  try {
    // Attempt to fetch from Supabase table 'medicines'
    let sel = supabase
      .from('medicines')
      .select('*');
    if (query) sel = sel.ilike('name', `%${query}%`);
    const { data, error } = await sel;
    if (!error && data && data.length > 0) {
      medicinesFromDb = data;
    }
  } catch (err) {
    // fail silently, fallback to mock data
  }

  // Normalize DB or fallback
  const meds = medicinesFromDb.length > 0
    ? medicinesFromDb.map((m:any, idx:number) => ({
        ...m,
        // default images/meta for now, please expand as needed for your DB
        id: m.id || idx+1,
        image: m.image || 'https://images.unsplash.com/photo-1511174511562-5f97f2b2c02e?auto=format&fit=facearea&w=128&h=128',
        description: m.description || '',
        platforms: [] // will fill below
      }))
    : (!query
        ? Object.values(MEDICINE_META)
        : Object.values(MEDICINE_META).filter(meta => meta.name.toLowerCase().includes(query.toLowerCase()))
      );

  // For each medicine, get provider platform stubs
  const products = await Promise.all(
    meds.map( async (meta:any) => {
      let platforms;
      // Only fetch from providers if not empty (demo: always show provider pricing)
      if (PROVIDERS.length > 0) {
        platforms = await Promise.all(
          PROVIDERS.map(provider => provider.fetchPrices(meta.name))
        );
      } else {
        platforms = [];
      }
      return { ...meta, platforms };
    })
  );
  return NextResponse.json({ products });
}
