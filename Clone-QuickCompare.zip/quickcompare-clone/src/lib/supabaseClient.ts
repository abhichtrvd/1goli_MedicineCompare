import { createClient } from '@supabase/supabase-js';

// Use your project-specific values here
const supabaseUrl = 'https://aqapazvdqbykkqggjvkz.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFxYXBhenZkcWJ5a2txZ2dqdmt6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkxMDA5NzgsImV4cCI6MjA2NDY3Njk3OH0.sjKxTkAHz-Eb5AVEJDRaUy4KlGXKD0kUUFvLKpTXSYY';

export const supabase = createClient(supabaseUrl, supabaseKey);
